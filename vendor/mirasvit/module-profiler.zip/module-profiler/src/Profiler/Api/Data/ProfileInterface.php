<?php
namespace Mirasvit\Profiler\Api\Data;

interface ProfileInterface
{
    /**
     * @return array
     */
    public function dump();
}