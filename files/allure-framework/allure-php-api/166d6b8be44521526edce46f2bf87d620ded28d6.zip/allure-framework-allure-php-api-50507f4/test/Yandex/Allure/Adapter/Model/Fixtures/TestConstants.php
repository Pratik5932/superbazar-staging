<?php

namespace Yandex\Allure\Adapter\Model\Fixtures;

class TestConstants
{
    public const TEST_CONSTANT = 'test-value';
}
