# Rule Functional Tests

The Functional Test Module for **Magento Rule** module.
