Magento_Review module functionality allows to write reviews for products.
