# Magento_NewsletterGraphQl module

This module allows a shopper to subscribe to a newsletter using GraphQL.

## Installation

Before installing this module, note that the Magento_NewsletterGraphQl is dependent on the Magento_Newsletter module.

For information about a module installation in Magento 2, see [Enable or disable modules](https://devdocs.magento.com/guides/v2.4/install-gde/install/cli/install-cli-subcommands-enable.html).

## Extensibility

Extension developers can interact with the Magento_NewsletterGraphQl module. For more information about the Magento extension mechanism, see [Magento plug-ins](https://devdocs.magento.com/guides/v2.4/extension-dev-guide/plugins.html).

[The Magento dependency injection mechanism](https://devdocs.magento.com/guides/v2.4/extension-dev-guide/depend-inj.html) enables you to override the functionality of the Magento_NewsletterGraphQl module.
