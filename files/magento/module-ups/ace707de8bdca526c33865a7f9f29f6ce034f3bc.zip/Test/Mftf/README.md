# Ups Functional Tests

The Functional Test Module for **Magento Ups** module.
