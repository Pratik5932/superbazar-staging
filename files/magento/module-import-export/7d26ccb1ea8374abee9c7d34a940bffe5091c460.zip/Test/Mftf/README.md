# Import Export Functional Tests

The Functional Test Module for **Magento Import Export** module.
