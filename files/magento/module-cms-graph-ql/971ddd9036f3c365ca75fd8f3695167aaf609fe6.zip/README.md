# CmsGraphQl

**CmsGraphQl** provides type information for the GraphQl module
to generate CMS fields for cms information endpoints.
