# WeeeGraphQl

**WeeeGraphQl** provides type information for the GraphQl module
to generate wee tax fields for catalog and product information endpoints.
