<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

return [
    'TestIntegration1' => [
        'email' => 'test-integration1@magento.com',
        'endpoint_url' => 'http://endpoint.com',
        'identity_link_url' => 'http://www.example.com/identity',
    ],
    'TestIntegration2' => ['email' => 'test-integration2@magento.com']
];
