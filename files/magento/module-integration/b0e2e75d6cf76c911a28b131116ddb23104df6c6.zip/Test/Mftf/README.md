# Integration Functional Tests

The Functional Test Module for **Magento Integration** module.
