# Swatches Layered Navigation Functional Tests

The Functional Test Module for **Magento Swatches Layered Navigation** module.
