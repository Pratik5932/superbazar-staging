# The Magento SwatchesLayeredNavigation Module

## Overview

The **Magento_SwatchesLayeredNavigation** module enables LayeredNavigation functionality for Swatch attributes

## Backward incompatible changes
No backward incompatible changes

## Dependencies
The **Magento_SwatchesLayeredNavigation** is dependent on the following modules:

- Magento_Swatches
- Magento_LayeredNavigation

## Specific Settings
The **Magento_SwatchesLayeredNavigation** module does not provide any specific settings.

## Specific Extension Points
The **Magento_SwatchesLayeredNavigation** module does not provide any specific extension points. You can extend it using the Magento extension mechanism.
