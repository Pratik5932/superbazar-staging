# AuthorizenetAcceptjs Functional Tests

The Functional Test Module for **Magento AuthorizenetAcceptjs** module.
