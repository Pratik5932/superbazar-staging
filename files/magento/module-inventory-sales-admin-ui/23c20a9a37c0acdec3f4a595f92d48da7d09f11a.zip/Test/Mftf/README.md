# Inventory Sales Admin Ui Functional Tests

The Functional Test Module for **Magento Inventory Sales Admin Ui** module.
