# Magento_AwsS3PageBuilder module

The Magento_AwsS3PageBuilder module created for maintaining Page Builder tests related to Aws S3 remote storage functionality
