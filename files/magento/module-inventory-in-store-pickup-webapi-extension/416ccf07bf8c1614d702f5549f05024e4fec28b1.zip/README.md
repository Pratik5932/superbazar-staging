# InventoryInStorePickupWebapiExtension module (Abandoned)

The `InventoryInStorePickupWebapiExtension`  is a part of `InStorePickup` implementation.

This module is part of the new inventory infrastructure. The
[Inventory Management overview](https://devdocs.magento.com/guides/v2.4/inventory/index.html)
describes the MSI (Multi-Source Inventory) project in more detail.
The module provide fix for usage of extension attributes as parameter for get endpoint in web API.
The module is abandoned and will be removed as soon as fix for the described issue will be released.

Please check links for more details:

* [Original issue in Core Repository](https://github.com/magento/magento2/issues/24116)  
* [Issue in MSI Repository](https://github.com/magento-engcom/msi/issues/2507)

## Installation details

This module is installed as part of Magento Open Source.
