# Magento_LoginAsCustomerSales module

This module is responsible for communication between Magento_LoginAsCustomer and order placement.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://docs.magento.com/user-guide/customers/login-as-customer.html).
