# Product Video Functional Tests

The Functional Test Module for **Magento Product Video** module.
