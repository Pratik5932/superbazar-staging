Provides self-signed JWT support for admin users' and customers' web API authentication. Replaces opaque tokens.
