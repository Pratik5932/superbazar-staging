The Magento_OfflineShipping module implements the shipping methods which do not involve a direct interaction with shipping carriers, so called offline shipping methods. Namely, the following:
*Free Shipping
*Flat Rate
*Table Rates
*Store Pickup

