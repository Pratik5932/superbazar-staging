# Google Optimizer Functional Tests

The Functional Test Module for **Magento Google Optimizer** module.
