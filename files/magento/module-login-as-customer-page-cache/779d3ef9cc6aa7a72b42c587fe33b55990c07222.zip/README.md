# Magento_LoginAsCustomerPageCache module

This module provides adaptation to PageCache functionality for Login as Customer functionality.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://docs.magento.com/user-guide/customers/login-as-customer.html).
