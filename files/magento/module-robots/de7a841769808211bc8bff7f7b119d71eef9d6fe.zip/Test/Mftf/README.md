# Robots Functional Tests

The Functional Test Module for **Magento Robots** module.
