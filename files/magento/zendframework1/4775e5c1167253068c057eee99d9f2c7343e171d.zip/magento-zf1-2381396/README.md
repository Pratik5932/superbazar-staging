INFORMATION
===================

This is a fork from Zend Framework 1.12.16 Release.

PURPOSE
---------------------------
Contains Zend Framework 1 plus performance improvements and bug fixes.

LICENSE
=======

The files in this archive are released under the Zend Framework license.
You can find a copy of this license in [LICENSE.txt](LICENSE.txt).
