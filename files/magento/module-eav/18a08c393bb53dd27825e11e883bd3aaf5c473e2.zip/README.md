Magento\EAV stands for Entity-Attribute-Value. The purpose of Magento\Eav module is to make entities
configurable/extendable by admin user.