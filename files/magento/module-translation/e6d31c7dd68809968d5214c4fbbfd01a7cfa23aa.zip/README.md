# Translation

**Translation** enables localization of a store for multiple regions and markets.
Also provides the inline translation tool.
