Magento_Reports module provides ability to collect various reports such as:
 - products reports (bestsellers, low stock, most viewed, products ordered),
 - sales reports (orders, tax, invoiced, shipping, refunds, coupons, and PayPal settlement reports),
 - customer reports (new accounts, customer by order totals, customers by number of orders),
 - shopping cart reports (products in cart, abandoned carts)
