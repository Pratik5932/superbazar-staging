# Swatches Graph Ql Functional Tests

The Functional Test Module for **Magento Swatches Graph Ql** module.
