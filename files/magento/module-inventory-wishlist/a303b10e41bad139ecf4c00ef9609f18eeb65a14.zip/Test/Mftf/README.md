# Inventory Wishlist Functional Tests

The Functional Test Module for **Magento Inventory Wishlist** module.
