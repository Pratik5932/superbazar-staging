The InventoryWishlist module adds multi-sourcing capabilities to the Wishlist module
