# Downloadable Graph Ql Functional Tests

The Functional Test Module for **Magento Customer Downloadable Graph Ql** module.
