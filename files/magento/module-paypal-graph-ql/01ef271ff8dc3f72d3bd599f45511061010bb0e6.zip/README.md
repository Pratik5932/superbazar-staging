# PaypalGraphQl

**PaypalGraphQl** provides resolver information for using Paypal payment methods via GraphQl.
