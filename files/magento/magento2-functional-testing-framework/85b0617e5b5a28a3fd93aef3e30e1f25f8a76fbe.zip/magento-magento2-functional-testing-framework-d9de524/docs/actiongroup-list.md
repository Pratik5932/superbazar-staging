# MFTF action group reference

Action groups are important building blocks for quickly creating tests for the Magento Functional Testing Framework.
This page lists all current action groups so developers can see what is available to them.

{% include mftf/actiongroup_data.md %}
