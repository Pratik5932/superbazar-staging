---
name: Existing rule enhancement
about: Improvement for existing Magento Coding Standard rule
title: ''
labels: enhancement
assignees: ''

---

### Description
<!--- Describe the enhancement you would like to make. -->

### Expected behavior
<!--- What is the expected behavior of this improvement? -->

### Benefits
<!--- How do you think this feature would improve Magento Coding Standard? -->

### Additional information
<!--- What other information can you provide about the desired feature? -->
