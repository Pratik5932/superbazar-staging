---
name: New rule proposal
about: Proposal for new Magento Coding Standard rule
title: ''
labels: proposal
assignees: ''

---

### Rule
<!--- Provide a high level explanation of the rule -->

### Reason
<!--- Explain, why this rule improves code quality -->

### Implementation
<!--- If possible: how to technically check the compliance to this rule -->
