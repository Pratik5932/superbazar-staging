Module can contain:
- Features which are used by our other modules (License, Menu, CompatibilityService)

Please discuss with dev team in our slack before adding any new features to this module.
