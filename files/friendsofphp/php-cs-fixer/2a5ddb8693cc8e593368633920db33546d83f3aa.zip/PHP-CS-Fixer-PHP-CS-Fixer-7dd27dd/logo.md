The logo is © 2010-2014 Sensio Labs.

Original resolution can be found at https://github.com/PHP-CS-Fixer/logo .
