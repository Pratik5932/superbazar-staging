============================
Rule set ``@PHP71Migration``
============================

Rules to improve code for PHP 7.1 compatibility.

Rules
-----

- `@PHP70Migration <./PHP70Migration.rst>`_
- `visibility_required <./../rules/class_notation/visibility_required.rst>`_
  config:
  ``['elements' => ['const', 'method', 'property']]``
