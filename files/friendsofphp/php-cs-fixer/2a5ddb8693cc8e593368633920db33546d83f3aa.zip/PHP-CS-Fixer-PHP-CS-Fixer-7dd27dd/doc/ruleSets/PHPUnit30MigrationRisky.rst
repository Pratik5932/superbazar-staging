======================================
Rule set ``@PHPUnit30Migration:risky``
======================================

Rules to improve tests code for PHPUnit 3.0 compatibility. This set contains rules that are risky.

Rules
-----

- `php_unit_dedicate_assert <./../rules/php_unit/php_unit_dedicate_assert.rst>`_
  config:
  ``['target' => '3.0']``
