<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Model;

use Eway\EwayRapid\Model\DummyPaymentDataObjectFactory;
use Eway\EwayRapid\Model\Ui\ConfigProvider;
use Eway\IFrame\Model\GetAccessCodeService;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\DataObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Command\CommandPool;
use Magento\Payment\Gateway\Command\ResultInterface;
use Magento\Payment\Gateway\CommandInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeServiceTest extends TestCase
{
    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var ConfigProvider
     */
    protected $configProvider;

    /**
     * @var \Eway\EwayRapid\Model\DummyPaymentInfoFactory
     */
    private $dummyPaymentInfoFactory;

    /**
     * @var \Eway\EwayRapid\Model\DummyPaymentDataObjectFactory
     */
    private $dummyPaymentDataObjectFactory;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->resultJsonFactory = Mockery::mock(JsonFactory::class);
        $this->configProvider = Mockery::mock(ConfigProvider::class);
        $this->dummyPaymentInfoFactory = Mockery::mock(\Eway\EwayRapid\Model\DummyPaymentInfoFactory::class);
        $this->dummyPaymentDataObjectFactory = Mockery::mock(DummyPaymentDataObjectFactory::class);
    }

    public function testProcess()
    {
        $tokenId = '1';
        $resultArray = [
            'AccessCode' => 'AccessCode',
            'SharedPaymentUrl' => 'SharedPaymentUrl',
            'FormActionURL' => 'FormActionURL',
        ];
        $dataObject = $this->getDataObjectMock();
        $dummyPaymentInfoFactory = $this->getDummyPaymentInfoFactoryMock();
        $dummyPaymentDataObjectFactory = $this->getDummyPaymentDataObjectFactoryMock();
        $methodSpecificConfigInterface = $this->getMethodSpecificConfigInterfaceMock();
        $commandPool = $this->getCommandPoolMock();
        $payment = $this->getInfoInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $dataObject->shouldReceive('getData')->andReturn($tokenId);
        $dataObject->shouldReceive('setData')->andReturnSelf();
        $this->dummyPaymentInfoFactory->shouldReceive('create')->andReturn($dummyPaymentInfoFactory);
        $this->dummyPaymentDataObjectFactory->shouldReceive('create')->andReturn($dummyPaymentDataObjectFactory);
        $this->configProvider->shouldReceive('getActiveMethodConfig')->andReturn($methodSpecificConfigInterface);
        $methodSpecificConfigInterface->shouldReceive('getCommandPool')->andReturn($commandPool);
        $dummyPaymentDataObjectFactory->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurn($resultInterface);
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($dataObject);
        $this->assertEquals($json, $result);
    }

    public function testProcessHasNoTokenId()
    {
        $tokenId = '';
        $resultArray = [
            'AccessCode' => 'AccessCode',
            'SharedPaymentUrl' => 'SharedPaymentUrl',
            'FormActionURL' => 'FormActionURL',
        ];
        $dataObject = $this->getDataObjectMock();
        $dummyPaymentInfoFactory = $this->getDummyPaymentInfoFactoryMock();
        $dummyPaymentDataObjectFactory = $this->getDummyPaymentDataObjectFactoryMock();
        $methodSpecificConfigInterface = $this->getMethodSpecificConfigInterfaceMock();
        $commandPool = $this->getCommandPoolMock();
        $payment = $this->getInfoInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $dataObject->shouldReceive('getData')->andReturn($tokenId);
        $dataObject->shouldReceive('setData')->andReturnSelf();
        $this->dummyPaymentInfoFactory->shouldReceive('create')->andReturn($dummyPaymentInfoFactory);
        $this->dummyPaymentDataObjectFactory->shouldReceive('create')->andReturn($dummyPaymentDataObjectFactory);
        $this->configProvider->shouldReceive('getActiveMethodConfig')->andReturn($methodSpecificConfigInterface);
        $methodSpecificConfigInterface->shouldReceive('getCommandPool')->andReturn($commandPool);
        $dummyPaymentDataObjectFactory->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurn($resultInterface);
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($dataObject);
        $this->assertEquals($json, $result);
    }

    public function testProcessCommandReturnNull()
    {
        $tokenId = '1';
        $resultArray = [];
        $dataObject = $this->getDataObjectMock();
        $dummyPaymentInfoFactory = $this->getDummyPaymentInfoFactoryMock();
        $dummyPaymentDataObjectFactory = $this->getDummyPaymentDataObjectFactoryMock();
        $methodSpecificConfigInterface = $this->getMethodSpecificConfigInterfaceMock();
        $commandPool = $this->getCommandPoolMock();
        $payment = $this->getInfoInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $dataObject->shouldReceive('getData')->andReturn($tokenId);
        $dataObject->shouldReceive('setData')->andReturnSelf();
        $this->dummyPaymentInfoFactory->shouldReceive('create')->andReturn($dummyPaymentInfoFactory);
        $this->dummyPaymentDataObjectFactory->shouldReceive('create')->andReturn($dummyPaymentDataObjectFactory);
        $this->configProvider->shouldReceive('getActiveMethodConfig')->andReturn($methodSpecificConfigInterface);
        $methodSpecificConfigInterface->shouldReceive('getCommandPool')->andReturn($commandPool);
        $dummyPaymentDataObjectFactory->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setHttpResponseCode')->andReturnSelf();
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($dataObject);
        $this->assertEquals($json, $result);
    }

    public function testProcessHasResultNull()
    {
        $tokenId = '1';
        $resultArray = [];
        $dataObject = $this->getDataObjectMock();
        $dummyPaymentInfoFactory = $this->getDummyPaymentInfoFactoryMock();
        $dummyPaymentDataObjectFactory = $this->getDummyPaymentDataObjectFactoryMock();
        $methodSpecificConfigInterface = $this->getMethodSpecificConfigInterfaceMock();
        $commandPool = $this->getCommandPoolMock();
        $payment = $this->getInfoInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $dataObject->shouldReceive('getData')->andReturn($tokenId);
        $dataObject->shouldReceive('setData')->andReturnSelf();
        $this->dummyPaymentInfoFactory->shouldReceive('create')->andReturn($dummyPaymentInfoFactory);
        $this->dummyPaymentDataObjectFactory->shouldReceive('create')->andReturn($dummyPaymentDataObjectFactory);
        $this->configProvider->shouldReceive('getActiveMethodConfig')->andReturn($methodSpecificConfigInterface);
        $methodSpecificConfigInterface->shouldReceive('getCommandPool')->andReturn($commandPool);
        $dummyPaymentDataObjectFactory->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurn($resultInterface);
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setHttpResponseCode')->andReturnSelf();
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($dataObject);
        $this->assertEquals($json, $result);
    }

    /**
     * @return DataObject|LegacyMockInterface|MockInterface
     */
    public function getDataObjectMock()
    {
        return Mockery::mock(DataObject::class);
    }

    /**
     * @return \Eway\EwayRapid\Model\DummyPaymentInfoFactory|LegacyMockInterface|MockInterface
     */
    public function getDummyPaymentInfoFactoryMock()
    {
        return Mockery::mock(\Eway\EwayRapid\Model\DummyPaymentInfoFactory::class);
    }

    /**
     * @return \Eway\EwayRapid\Model\DummyPaymentDataObjectFactory|LegacyMockInterface|MockInterface
     */
    public function getDummyPaymentDataObjectFactoryMock()
    {
        return Mockery::mock(\Eway\EwayRapid\Model\DummyPaymentDataObjectFactory::class);
    }

    /**
     * @return \Eway\EwayRapid\Model\Ui\MethodSpecificConfigInterface|LegacyMockInterface|MockInterface
     */
    public function getMethodSpecificConfigInterfaceMock()
    {
        return Mockery::mock(\Eway\EwayRapid\Model\Ui\MethodSpecificConfigInterface::class);
    }

    /**
     * @return CommandPool|LegacyMockInterface|MockInterface
     */
    public function getCommandPoolMock()
    {
        return Mockery::mock(CommandPool::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return CommandInterface|LegacyMockInterface|MockInterface
     */
    public function getCommandInterfaceMock()
    {
        return Mockery::mock(CommandInterface::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|ResultInterface
     */
    public function getResultInterfaceMock()
    {
        return Mockery::mock(ResultInterface::class);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCodeService::class, [
            'resultJsonFactory' => $this->resultJsonFactory,
            'configProvider' => $this->configProvider,
            'dummyPaymentInfoFactory' => $this->dummyPaymentInfoFactory,
            'dummyPaymentDataObjectFactory' => $this->dummyPaymentDataObjectFactory,
        ]);
    }
}
