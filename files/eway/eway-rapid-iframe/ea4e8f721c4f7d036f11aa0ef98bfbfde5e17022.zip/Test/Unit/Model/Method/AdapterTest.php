<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Model\Method;

use Eway\EwayRapid\Model\Config;
use Eway\IFrame\Model\Method\Adapter as IFrameAdapter;
use Magento\Framework\DataObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class AdapterTest extends TestCase
{
    /**
     * @var InfoInterface
     */
    protected $infoInstance;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->infoInstance = Mockery::mock(InfoInterface::class);
    }

    public function assignData(\Magento\Framework\DataObject $data)
    {
        parent::assignData($data);

        if (($addtionalData = $data->getData('additional_data')) && isset($addtionalData[Config::ACCESS_CODE])) {
            $this->getInfoInstance()->setAdditionalInformation(
                Config::ACCESS_CODE,
                $addtionalData[Config::ACCESS_CODE]
            );
        }
        $addtionalFields = [
            Config::TOKEN_ACTION, Config::TOKEN_ID,
            Config::CARD_NUMBER, Config::CARD_CVN, Config::CARD_NAME,
            Config::CARD_EXPIRY_MONTH, Config::CARD_EXPIRY_YEAR, Config::SECURED_CARD_DATA,
        ];

        foreach ($addtionalFields as $field) {
            if (isset($addtionalData[$field])) {
                $this->getInfoInstance()->setAdditionalInformation($field, $addtionalData[$field]);
            }
        }

        return $this;
    }

    public function testAssignData()
    {
        $data = [
            'data' => 'data',
            'AccessCode' => 'data',
            'TokenAction' => 'action',
            'TokenID' => '123',
            'Number' => '123',
            'CVN' => '123',
            'Name' => 'name',
            'ExpiryMonth' => '12',
            'ExpiryYear' => '12',
            'SecuredCardData' => 'card',
        ];

        $addtionalFields = [
            Config::TOKEN_ACTION, Config::TOKEN_ID,
            Config::CARD_NUMBER, Config::CARD_CVN, Config::CARD_NAME,
            Config::CARD_EXPIRY_MONTH, Config::CARD_EXPIRY_YEAR, Config::SECURED_CARD_DATA,
        ];
        $dataObject = $this->getDataObjectMock();
        $dataObject->shouldReceive('getData')->andReturn($data);
        $this->infoInstance->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $this->infoInstance->shouldReceive('setAdditionalInformation')->with($addtionalFields)->once()->andReturnSelf();
        $this->infoInstance->shouldReceive('setAdditionalInformation')
            ->with($addtionalFields)
            ->twice()
            ->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->assignData($dataObject);
        $this->assertInstanceOf(IFrameAdapter::class, $result);
    }

    /**
     * @return DataObject|LegacyMockInterface|MockInterface
     */
    public function getDataObjectMock()
    {
        return Mockery::mock(DataObject::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(IFrameAdapter::class, [
            'infoInstance' => $this->infoInstance,
        ]);
    }
}
