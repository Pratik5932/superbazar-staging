<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Model;

use Eway\EwayRapid\Model\Config;
use Eway\IFrame\Model\GetAccessCodeTransactionService;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Command\CommandPoolInterface;
use Magento\Payment\Gateway\Command\ResultInterface;
use Magento\Payment\Gateway\CommandInterface;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectFactory;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Payment;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeTransactionServiceTest extends TestCase
{
    /**
     * @var CommandPoolInterface
     */
    protected $commandPool;

    /**
     * @var PaymentDataObjectFactory
     */
    protected $paymentDataObjectFactory;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var ConfigInterface
     */
    protected $config;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->commandPool = Mockery::mock(CommandPoolInterface::class);
        $this->paymentDataObjectFactory = Mockery::mock(PaymentDataObjectFactory::class);
        $this->resultJsonFactory = Mockery::mock(JsonFactory::class);
        $this->config = Mockery::mock(ConfigInterface::class);
    }

    public function process(Quote $quote, RequestInterface $request): Json
    {
        if (!$quote->getReservedOrderId()) {
            $quote->reserveOrderId()->save();
        }
        $payment = $quote->getPayment();

        if ($this->config->getValue('token_enabled')) {
            // Reset token information
            $payment->setAdditionalInformation(Config::TOKEN_ACTION, null);
            $payment->setAdditionalInformation(Config::TOKEN_ID, null);

            if ($action = $request->getParam(Config::TOKEN_ACTION)) {
                $payment->setAdditionalInformation(Config::TOKEN_ACTION, $action);

                if ($tokenID = $request->getParam(Config::TOKEN_ID)) {
                    $payment->setAdditionalInformation(Config::TOKEN_ID, $tokenID);
                }
            }

            $payment->save();
        }

        $paymentDataObject = $this->paymentDataObjectFactory->create($payment);

        try {
            $result = $this->commandPool->get(self::COMMAND_GET_ACCESS_CODE)->execute([
                'payment' => $paymentDataObject,
                'amount' => $quote->getGrandTotal(),
            ]);

            if (null === $result) {
                throw new LocalizedException(__('Error happened when getting access code, please try again later'));
            }

            $result = $result->get();

            if (!isset($result[Config::ACCESS_CODE])) {
                throw new LocalizedException(__('Error happened when getting access code, please try again later'));
            }

            $payment->setAdditionalInformation(Config::ACCESS_CODE, $result[Config::ACCESS_CODE]);
            $payment->save();

            $jsonData = [
                'access_code' => $result[Config::ACCESS_CODE],
            ];
            if (isset($result[Config::SHARED_PAYMENT_URL])) {
                $jsonData['shared_payment_url'] = $result[Config::SHARED_PAYMENT_URL];
            }
            if (isset($result[Config::FORM_ACTION_URL])) {
                $jsonData['form_action_url'] = $result[Config::FORM_ACTION_URL];
            }

            return $this->resultJsonFactory->create()->setData($jsonData);
        } catch (\Exception $e) {
            return $this->resultJsonFactory->create()->setHttpResponseCode(400)->setData([
                'error' => $e->getMessage(),
            ]);
        }
    }

    public function testProcess()
    {
        $reservedOrderId = '';
        $tokenId = '1';
        $grandTotal = '1000';
        $resultArray = [
            'AccessCode' => 'AccessCode',
            'SharedPaymentUrl' => 'SharedPaymentUrl',
            'FormActionURL' => 'FormActionURL',
        ];
        $quote = $this->getQuoteMock();
        $payment = $this->getPaymentMock();
        $request = $this->getRequestInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $paymentDataObjectInterface = $this->getPaymentDataObjectInterfaceMock();
        $quote->shouldReceive('getReservedOrderId')->andReturn($reservedOrderId);
        $quote->shouldReceive('reserveOrderId')->andReturnSelf();
        $quote->shouldReceive('save')->andReturnSelf();
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $this->config->shouldReceive('getValue')->andReturnTrue();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $request->shouldReceive('getParam')->andReturnTrue();
        $request->shouldReceive('getParam')->andReturn($tokenId);
        $payment->shouldReceive('save')->andReturnSelf();
        $this->paymentDataObjectFactory->shouldReceive('create')->andReturn($paymentDataObjectInterface);
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurn($resultInterface);
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $quote->shouldReceive('getGrandTotal')->andReturn($grandTotal);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($quote, $request);
        $this->assertEquals($json, $result);
    }

    public function testProcessCommandReturnNull()
    {
        $reservedOrderId = '1';
        $tokenId = '1';
        $grandTotal = '1000';
        $resultArray = [
            'AccessCode' => 'AccessCode',
            'SharedPaymentUrl' => 'SharedPaymentUrl',
            'FormActionURL' => 'FormActionURL',
        ];
        $quote = $this->getQuoteMock();
        $payment = $this->getPaymentMock();
        $request = $this->getRequestInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $paymentDataObjectInterface = $this->getPaymentDataObjectInterfaceMock();
        $quote->shouldReceive('getReservedOrderId')->andReturn($reservedOrderId);
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $this->config->shouldReceive('getValue')->andReturnTrue();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $request->shouldReceive('getParam')->andReturnTrue();
        $request->shouldReceive('getParam')->andReturn($tokenId);
        $payment->shouldReceive('save')->andReturnSelf();
        $this->paymentDataObjectFactory->shouldReceive('create')->andReturn($paymentDataObjectInterface);
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $quote->shouldReceive('getGrandTotal')->andReturn($grandTotal);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setHttpResponseCode')->andReturnSelf();
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($quote, $request);
        $this->assertEquals($json, $result);
    }

    public function testProcessHasResultNull()
    {
        $reservedOrderId = '1';
        $tokenId = '1';
        $grandTotal = '1000';
        $resultArray = [];
        $quote = $this->getQuoteMock();
        $payment = $this->getPaymentMock();
        $request = $this->getRequestInterfaceMock();
        $command = $this->getCommandInterfaceMock();
        $resultInterface = $this->getResultInterfaceMock();
        $json = $this->getJsonMock();
        $paymentDataObjectInterface = $this->getPaymentDataObjectInterfaceMock();
        $quote->shouldReceive('getReservedOrderId')->andReturn($reservedOrderId);
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $this->config->shouldReceive('getValue')->andReturnTrue();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $payment->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $request->shouldReceive('getParam')->andReturnTrue();
        $request->shouldReceive('getParam')->andReturn($tokenId);
        $payment->shouldReceive('save')->andReturnSelf();
        $this->paymentDataObjectFactory->shouldReceive('create')->andReturn($paymentDataObjectInterface);
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurn($resultInterface);
        $resultInterface->shouldReceive('get')->andReTurn($resultArray);
        $quote->shouldReceive('getGrandTotal')->andReturn($grandTotal);
        $this->resultJsonFactory->shouldReceive('create')->andReturn($json);
        $json->shouldReceive('setHttpResponseCode')->andReturnSelf();
        $json->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->process($quote, $request);
        $this->assertEquals($json, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Quote
     */
    public function getQuoteMock()
    {
        return Mockery::mock(Quote::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Payment
     */
    public function getPaymentMock()
    {
        return Mockery::mock(Payment::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|RequestInterface
     */
    public function getRequestInterfaceMock()
    {
        return Mockery::mock(RequestInterface::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|PaymentDataObjectInterface
     */
    public function getPaymentDataObjectInterfaceMock()
    {
        return Mockery::mock(PaymentDataObjectInterface::class);
    }

    /**
     * @return CommandInterface|LegacyMockInterface|MockInterface
     */
    public function getCommandInterfaceMock()
    {
        return Mockery::mock(CommandInterface::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|ResultInterface
     */
    public function getResultInterfaceMock()
    {
        return Mockery::mock(ResultInterface::class);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCodeTransactionService::class, [
            'commandPool' => $this->commandPool,
            'paymentDataObjectFactory' => $this->paymentDataObjectFactory,
            'resultJsonFactory' => $this->resultJsonFactory,
            'config' => $this->config,
        ]);
    }
}
