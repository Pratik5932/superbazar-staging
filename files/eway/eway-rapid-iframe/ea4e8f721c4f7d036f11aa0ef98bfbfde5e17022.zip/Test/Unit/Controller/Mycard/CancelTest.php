<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Mycard;

use Eway\IFrame\Controller\Mycard\Cancel;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class CancelTest extends TestCase
{
    /**
     * @var RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->resultRedirectFactory = Mockery::mock(RedirectFactory::class);
    }

    public function testExecute()
    {
        $redirect = $this->getRedirectMock();
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($redirect, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Redirect
     */
    public function getRedirectMock()
    {
        return Mockery::mock(Redirect::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(Cancel::class, [
            'resultRedirectFactory' => $this->resultRedirectFactory,
        ]);
    }
}
