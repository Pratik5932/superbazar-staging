<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Mycard;

use Eway\IFrame\Controller\Mycard\GetAccessCode;
use Eway\IFrame\Model\GetAccessCodeService;
use Magento\Directory\Helper\Data;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\DataObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeTest extends TestCase
{
    /**
     * @var GetAccessCodeService
     */
    protected $getAccessCodeService;

    /**
     * @var Data
     */
    private $directoryHelper;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->getAccessCodeService = Mockery::mock(GetAccessCodeService::class);
        $this->directoryHelper = Mockery::mock(Data::class);
        $this->request = Mockery::mock(RequestInterface::class);
    }

    public function testExecute()
    {
        $params = [
            'data' => 'data',
            'country_id' => '1',
            'region_id' => '1',
        ];

        $regionArray = [
            'data' => 'data',
            '1' => [
                '1' => [
                    'code' => 'data',
                ],
            ],
        ];

        $data = $this->getDataObjectMock();
        $json = $this->getJsonMock();
        $this->request->shouldReceive('getParams')->andReturn($params);
        $data->shouldReceive('getData')->andReturn($params['country_id']);
        $data->shouldReceive('getData')->andReturn($params['region_id']);
        $this->directoryHelper->shouldReceive('isRegionRequired')->andReturnTrue();
        $this->directoryHelper->shouldReceive('getRegionData')->andReturn($regionArray);
        $this->getAccessCodeService->shouldReceive('process')->andReturn($json);
        $data->shouldReceive('setData')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($json, $result);
    }

    /**
     * @return DataObject|LegacyMockInterface|MockInterface
     */
    public function getDataObjectMock()
    {
        return Mockery::mock(DataObject::class);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCode::class, [
            'getAccessCodeService' => $this->getAccessCodeService,
            'directoryHelper' => $this->directoryHelper,
            'request' => $this->request,
        ]);
    }
}
