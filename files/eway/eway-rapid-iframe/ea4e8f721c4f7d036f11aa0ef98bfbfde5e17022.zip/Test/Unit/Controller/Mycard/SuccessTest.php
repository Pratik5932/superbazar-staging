<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Mycard;

use Eway\EwayRapid\Model\Customer\TokenSaveService;
use Eway\IFrame\Controller\Mycard\Success;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\DataObject;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class SuccessTest extends TestCase
{
    /**
     * @var TokenSaveService
     */
    private $tokenSaveService;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * @var RedirectFactory
     */
    private $resultRedirectFactory;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->tokenSaveService = Mockery::mock(TokenSaveService::class);
        $this->request = Mockery::mock(RequestInterface::class);
        $this->messageManager = Mockery::mock(ManagerInterface::class);
        $this->resultRedirectFactory = Mockery::mock(RedirectFactory::class);
    }

    public function testExecute()
    {
        $tokenId = '1';
        $dataObject = $this->getDataObjectMock();
        $redirect = $this->getRedirectMock();
        $this->request->shouldReceive('getParam')->andReturn('AccessCode');
        $this->request->shouldReceive('getParam')->andReturn($tokenId);
        $dataObject->shouldReceive('setData')->andReturnSelf();
        $this->tokenSaveService->shouldReceive('process')->andReturnNull();
        $this->messageManager->shouldReceive('addSuccessMessage')->andReturnSelf();
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($redirect, $result);
    }

    public function testExecuteHasNoAccessCode()
    {
        $exceptionMessage = 'exception';
        $redirect = $this->getRedirectMock();
        $this->request->shouldReceive('getParam')->andReturnNull();
        $this->throwException(new \Exception($exceptionMessage));
        $this->messageManager->shouldReceive('addErrorMessage')->andReturnSelf();
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $subject->execute();
    }

    /**
     * @return DataObject|LegacyMockInterface|MockInterface
     */
    public function getDataObjectMock()
    {
        return Mockery::mock(DataObject::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Redirect
     */
    public function getRedirectMock()
    {
        return Mockery::mock(Redirect::class);
    }

    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(Success::class, [
            'tokenSaveService' => $this->tokenSaveService,
            'request' => $this->request,
            'messageManager' => $this->messageManager,
            'resultRedirectFactory' => $this->resultRedirectFactory,
        ]);
    }
}
