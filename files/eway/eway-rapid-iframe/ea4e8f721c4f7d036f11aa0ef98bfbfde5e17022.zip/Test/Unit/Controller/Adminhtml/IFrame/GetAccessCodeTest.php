<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Adminhtml\IFrame;

use Eway\IFrame\Controller\Adminhtml\IFrame\GetAccessCode;
use Eway\IFrame\Model\GetAccessCodeTransactionService;
use Magento\Backend\Model\Session\Quote as Session;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Quote\Model\Quote;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeTest extends TestCase
{
    /**
     * @var GetAccessCodeTransactionService
     */
    protected $getAccessCodeTransactionService;

    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->getAccessCodeTransactionService = Mockery::mock(GetAccessCodeTransactionService::class);
        $this->_objectManager = Mockery::mock(ObjectManagerInterface::class);
    }

    public function execute()
    {
        $this->_initSession();
        $quote = $this->_getQuote();

        return $this->getAccessCodeTransactionService->process($quote, $this->getRequest());
    }

    public function testExecute()
    {
        $json = $this->getJsonMock();
        $session = $this->getQuoteSessionMock();
        $quote = $this->getQuoteMock();
        $this->_objectManager->shouldReceive('get')->andReturn($session);
        $session->shouldReceive('getQuote')->andReturn($quote);
        $this->getAccessCodeTransactionService->shouldReceive('process')->andReturn($json);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($json, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Session
     */
    public function getQuoteSessionMock()
    {
        return Mockery::mock(Session::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Quote
     */
    public function getQuoteMock()
    {
        return Mockery::mock(Quote::class);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCode::class, [
            'getAccessCodeTransactionService' => $this->getAccessCodeTransactionService,
            '_objectManager' => $this->_objectManager,
        ]);
    }
}
