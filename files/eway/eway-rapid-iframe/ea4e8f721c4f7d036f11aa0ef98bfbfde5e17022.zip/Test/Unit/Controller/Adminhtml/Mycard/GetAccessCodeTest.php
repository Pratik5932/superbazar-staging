<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Adminhtml\Mycard;

use Eway\IFrame\Controller\Adminhtml\Mycard\GetAccessCode;
use Eway\IFrame\Model\GetAccessCodeService;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\DataObject;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeTest extends TestCase
{
    /**
     * @var GetAccessCodeService
     */
    protected $getAccessCodeService;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->getAccessCodeService = Mockery::mock(GetAccessCodeService::class);
        $this->request = Mockery::mock(RequestInterface::class);
    }

    public function execute()
    {
        $request = $this->getRequest();

        $data = new DataObject($request->getParams());

        return $this->getAccessCodeService->process($data);
    }

    public function testExecute()
    {
        $params = [
            'data' => 'data',
        ];
        $json = $this->getJsonMock();
        $this->request->shouldReceive('getParams')->andReturn($params);
        $this->getAccessCodeService->shouldReceive('process')->andReturn($json);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($json, $result);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCode::class, [
            'getAccessCodeService' => $this->getAccessCodeService,
            'request' => $this->request,
        ]);
    }
}
