<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\Redirect;

use Eway\EwayRapid\Model\Config;
use Eway\IFrame\Controller\Redirect\Success;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Quote\Api\CartManagementInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote\Payment;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class SuccessTest extends TestCase
{
    /**
     * @var CartManagementInterface
     */
    private $cartManagement;

    /**
     * @var CartRepositoryInterface
     */
    private $cartRepository;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var ManagerInterface
     */
    private $messageManager;

    /**
     * @var RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->cartManagement = Mockery::mock(CartManagementInterface::class);
        $this->cartRepository = Mockery::mock(CartRepositoryInterface::class);
        $this->request = Mockery::mock(RequestInterface::class);
        $this->messageManager = Mockery::mock(ManagerInterface::class);
        $this->resultRedirectFactory = Mockery::mock(RedirectFactory::class);
    }

    public function testExecute()
    {
        $accessCode = 'AccessCode';
        $cartId = '1';
        $customerId = '1';
        $orderId = '1';
        $redirect = $this->getRedirectMock();
        $quote = $this->getCartInterfaceMock();
        $payment = $this->getPaymentMock();
        $this->request->shouldReceive('getParam')->with('cart_id')->andReturn($cartId);
        $this->request->shouldReceive('getParam')->with(Config::ACCESS_CODE)->andReturn($accessCode);
        $this->cartRepository->shouldReceive('getActive')->andReturn($quote);
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('getAdditionalInformation')->andReturn($accessCode);
        $quote->shouldReceive('getCustomerId')->andReturn($customerId);
        $this->cartManagement->shouldReceive('placeOrder')->andReturn($orderId);
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($redirect, $result);
    }

    public function testExecuteQuoteHasNoAccessCode()
    {
        $accessCode = '';
        $cartId = '1';
        $quote = $this->getCartInterfaceMock();
        $payment = $this->getPaymentMock();
        $exceptionMessage = 'exception';
        $redirect = $this->getRedirectMock();
        $this->request->shouldReceive('getParam')->with('cart_id')->andReturn($cartId);
        $this->request->shouldReceive('getParam')->with(Config::ACCESS_CODE)->andReturn($accessCode);
        $this->cartRepository->shouldReceive('getActive')->andReturn($quote);
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('getAdditionalInformation')->andReturn('AccessCode');
        $this->throwException(new LocalizedException(__($exceptionMessage)));
        $this->messageManager->shouldReceive('addErrorMessage')->andReturnSelf();
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $subject->execute();
    }

    public function testExecuteQuoteHasNoCustomerId()
    {
        $accessCode = 'AccessCode';
        $cartId = '1';
        $customerId = '';
        $exceptionMessage = 'exception';
        $redirect = $this->getRedirectMock();
        $quote = $this->getCartInterfaceMock();
        $payment = $this->getPaymentMock();
        $this->request->shouldReceive('getParam')->with('cart_id')->andReturn($cartId);
        $this->request->shouldReceive('getParam')->with(Config::ACCESS_CODE)->andReturn($accessCode);
        $this->cartRepository->shouldReceive('getActive')->andReturn($quote);
        $quote->shouldReceive('getPayment')->andReturn($payment);
        $payment->shouldReceive('getAdditionalInformation')->andReturn($accessCode);
        $quote->shouldReceive('getCustomerId')->andReturn($customerId);
        $this->throwException(new LocalizedException(__($exceptionMessage)));
        $this->messageManager->shouldReceive('addErrorMessage')->andReturnSelf();
        $this->resultRedirectFactory->shouldReceive('create')->andReturn($redirect);
        $redirect->shouldReceive('setPath')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $subject->execute();
    }

    /**
     * @return CartInterface|LegacyMockInterface|MockInterface
     */
    public function getCartInterfaceMock()
    {
        return Mockery::mock(CartInterface::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Payment
     */
    public function getPaymentMock()
    {
        return Mockery::mock(Payment::class);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Redirect
     */
    public function getRedirectMock()
    {
        return Mockery::mock(Redirect::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(Success::class, [
            'cartManagement' => $this->cartManagement,
            'cartRepository' => $this->cartRepository,
            'request' => $this->request,
            'messageManager' => $this->messageManager,
            'resultRedirectFactory' => $this->resultRedirectFactory,
        ]);
    }
}
