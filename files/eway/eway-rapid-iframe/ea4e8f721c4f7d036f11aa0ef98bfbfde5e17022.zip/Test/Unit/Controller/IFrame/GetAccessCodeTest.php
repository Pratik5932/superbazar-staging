<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Controller\IFrame;

use Eway\IFrame\Controller\IFrame\GetAccessCode;
use Eway\IFrame\Model\GetAccessCodeTransactionService;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeTest extends TestCase
{
    /** @var Session */
    protected $checkoutSession;

    /** @var GetAccessCodeTransactionService */
    protected $getAccessCodeTransactionService;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->checkoutSession = Mockery::mock(Session::class);
        $this->getAccessCodeTransactionService = Mockery::mock(GetAccessCodeTransactionService::class);
        $this->request = Mockery::mock(RequestInterface::class);
    }

    public function testExecute()
    {
        $quote = $this->getQuoteMock();
        $address = $this->getAddressMock();
        $json = $this->getJsonMock();
        $this->checkoutSession->shouldReceive('getQuote')->andReturn($quote);
        $quote->shouldReceive('getBillingAddress')->andReturn($address);
        $address->shouldReceive('getEmail')->andReturnNull();
        $this->request->shouldReceive('getParam')->andReturn('eway@gmail.com');
        $this->request->shouldReceive('getParam')->andReturn('eway@gmail.com');
        $quote->shouldReceive('getBillingAddress')->andReturn($address);
        $address->shouldReceive('setEmail')->andReturnSelf();
        $this->getAccessCodeTransactionService->shouldReceive('process')->andReturn($json);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute();
        $this->assertEquals($json, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|Quote
     */
    public function getQuoteMock()
    {
        return Mockery::mock(Quote::class);
    }

    /**
     * @return Address|LegacyMockInterface|MockInterface
     */
    public function getAddressMock()
    {
        return Mockery::mock(Address::class);
    }

    /**
     * @return Json|LegacyMockInterface|MockInterface
     */
    public function getJsonMock()
    {
        return Mockery::mock(Json::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCode::class, [
            'checkoutSession' => $this->checkoutSession,
            'getAccessCodeTransactionService' => $this->getAccessCodeTransactionService,
            'request' => $this->request,
        ]);
    }
}
