<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Command;

use Eway\EwayRapid\Model\DummyPaymentDataObject;
use Eway\IFrame\Gateway\Command\MyCardCreateUpdateTokenCommand;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Command\CommandPoolInterface;
use Magento\Payment\Gateway\CommandInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class MyCardCreateUpdateTokenCommandTest extends TestCase
{
    /**
     * @var CommandPoolInterface
     */
    protected $commandPool;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->commandPool = Mockery::mock(CommandPoolInterface::class);
    }

    public function testExecute()
    {
        $paymentDO = $this->getDummyPaymentDataObjectMock();
        $array = [
            'data' => 'data',
            'payment' => $paymentDO,
        ];
        $command = $this->getCommandInterfaceMock();
        $infoInterface = $this->getInfoInterfaceMock();
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $paymentDO->shouldReceive('getPayment')->andReturn($infoInterface);
        $infoInterface->shouldReceive('getAdditionalInformation')->andReturn('123');
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute($array);
        $this->assertNull($result);
    }

    public function testExecuteHasNoTokenId()
    {
        $paymentDO = $this->getDummyPaymentDataObjectMock();
        $array = [
            'data' => 'data',
            'payment' => $paymentDO,
        ];
        $command = $this->getCommandInterfaceMock();
        $infoInterface = $this->getInfoInterfaceMock();
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $paymentDO->shouldReceive('getPayment')->andReturn($infoInterface);
        $infoInterface->shouldReceive('getAdditionalInformation')->andReturnNull();
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute($array);
        $this->assertNull($result);
    }

    /**
     * @return CommandInterface|LegacyMockInterface|MockInterface
     */
    public function getCommandInterfaceMock()
    {
        return Mockery::mock(CommandInterface::class);
    }

    /**
     * @return DummyPaymentDataObject|LegacyMockInterface|MockInterface
     */
    public function getDummyPaymentDataObjectMock()
    {
        return Mockery::mock(DummyPaymentDataObject::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(MyCardCreateUpdateTokenCommand::class, [
            'commandPool' => $this->commandPool,
        ]);
    }
}
