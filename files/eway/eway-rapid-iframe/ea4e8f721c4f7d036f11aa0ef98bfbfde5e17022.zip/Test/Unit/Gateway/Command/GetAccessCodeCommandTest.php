<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Command;

use Eway\IFrame\Gateway\Command\GetAccessCodeCommand;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Command\Result\ArrayResultFactory;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferFactoryInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class GetAccessCodeCommandTest extends TestCase
{
    /**
     * @var ArrayResultFactory
     */
    protected $arrayResultFactory;

    /**
     * @var BuilderInterface
     */
    protected $requestBuilder;

    /**
     * @var TransferFactoryInterface
     */
    protected $transferFactory;

    /**
     * @var ClientInterface
     */
    protected $client;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->arrayResultFactory = Mockery::mock(ArrayResultFactory::class);
        $this->requestBuilder = Mockery::mock(BuilderInterface::class);
        $this->transferFactory = Mockery::mock(TransferFactoryInterface::class);
        $this->client = Mockery::mock(ClientInterface::class);
    }

    public function testExecute()
    {
        $array = [
            'data' => 'data',
        ];
        $transfer = $this->getTransferInterfaceMock();
        $arrayResult = $this->getArrayResultFactoryMock();
        $this->transferFactory->shouldReceive('create')->andReturn($transfer);
        $this->requestBuilder->shouldReceive('build')->andReturn([]);
        $this->client->shouldReceive('placeRequest')->andReturn([]);
        $this->arrayResultFactory->shouldReceive('create')->andReturn($arrayResult);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->execute($array);
        $this->assertEquals($result, $arrayResult);
    }

    /**
     * @return LegacyMockInterface|MockInterface|TransferInterface
     */
    public function getTransferInterfaceMock()
    {
        return Mockery::mock(TransferInterface::class);
    }

    /**
     * @return ArrayResultFactory|LegacyMockInterface|MockInterface
     */
    public function getArrayResultFactoryMock()
    {
        return Mockery::mock(ArrayResultFactory::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(GetAccessCodeCommand::class, [
            'arrayResultFactory' => $this->arrayResultFactory,
            'requestBuilder' => $this->requestBuilder,
            'transferFactory' => $this->transferFactory,
            'client' => $this->client,
        ]);
    }
}
