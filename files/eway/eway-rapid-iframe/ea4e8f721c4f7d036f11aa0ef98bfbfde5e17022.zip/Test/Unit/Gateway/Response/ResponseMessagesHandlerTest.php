<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Response;

use Eway\IFrame\Gateway\Response\ResponseMessagesHandler;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Command\CommandPool;
use Magento\Payment\Gateway\CommandInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class ResponseMessagesHandlerTest extends TestCase
{
    /**
     * @var CommandPool
     */
    protected $commandPool;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->commandPool = Mockery::mock(CommandPool::class);
    }

    public function testHandle()
    {
        $payment = $this->getPaymentDataObjectInterfaceMock();

        $handlingSubject = [
            'data' => 'data',
            'payment' => $payment,
        ];

        $response = [
            'data' => 'data',
            'TransactionID' => '123',
        ];

        $command = $this->getCommandInterfaceMock();
        $infoInterface = $this->getInfoInterfaceMock();
        $payment->shouldReceive('getPayment')->andReturn($infoInterface);
        $infoInterface->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $this->commandPool->shouldReceive('get')->andReturn($command);
        $command->shouldReceive('execute')->andReTurnNull();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->handle($handlingSubject, $response);
        $this->assertNull($result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|PaymentDataObjectInterface
     */
    public function getPaymentDataObjectInterfaceMock()
    {
        return Mockery::mock(PaymentDataObjectInterface::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return CommandInterface|LegacyMockInterface|MockInterface
     */
    public function getCommandInterfaceMock()
    {
        return Mockery::mock(CommandInterface::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(ResponseMessagesHandler::class, [
            'commandPool' => $this->commandPool,
        ]);
    }
}
