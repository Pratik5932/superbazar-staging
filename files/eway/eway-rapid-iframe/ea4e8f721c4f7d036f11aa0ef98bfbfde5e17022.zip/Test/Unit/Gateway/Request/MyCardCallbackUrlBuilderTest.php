<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Request;

use Eway\EwayRapid\Model\Config;
use Eway\IFrame\Gateway\Request\MyCardCallbackUrlBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class MyCardCallbackUrlBuilderTest extends TestCase
{
    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->urlBuilder = Mockery::mock(UrlInterface::class);
    }

    public function testBuild()
    {
        $payment = $this->getPaymentDataObjectInterfaceMock();
        $buildSubject = [
            'payment' => $payment,
        ];
        $tokenId = '1';
        $redirectUrl = 'url';
        $cancelUrl = 'url';
        $array = [
            Config::REDIRECT_URL => $redirectUrl,
            Config::CANCEL_URL => $cancelUrl,
        ];
        $paymentModel = $this->getInfoInterfaceMock();
        $payment->shouldReceive('getPayment')->andReturn($paymentModel);
        $paymentModel->shouldReceive('getAdditionalInformation')->andReturn($tokenId);
        $this->urlBuilder->shouldReceive('getUrl')->andReturn($redirectUrl);
        $this->urlBuilder->shouldReceive('getUrl')->andReturn($cancelUrl);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->build($buildSubject);
        $this->assertEquals($array, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|PaymentDataObjectInterface
     */
    public function getPaymentDataObjectInterfaceMock()
    {
        return Mockery::mock(PaymentDataObjectInterface::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(MyCardCallbackUrlBuilder::class, [
            'urlBuilder' => $this->urlBuilder,
        ]);
    }
}
