<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Request;

use Eway\EwayRapid\Model\Config;
use Eway\IFrame\Gateway\Request\CallbackUrlBuilder;
use Magento\Checkout\Model\Session;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Framework\UrlInterface;
use Mockery;
use PHPUnit\Framework\TestCase;

class CallbackUrlBuilderTest extends TestCase
{
    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var Session
     */
    private $checkoutSession;

    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
        $this->urlBuilder = Mockery::mock(UrlInterface::class);
        $this->checkoutSession = Mockery::mock(Session::class);
    }

    public function testBuild()
    {
        $buildSubject = [];
        $redirectUrl = 'url';
        $cancelUrl = 'url';
        $array = [
            Config::REDIRECT_URL => $redirectUrl,
            Config::CANCEL_URL => $cancelUrl,
        ];
        $quoteId = '1';
        $this->checkoutSession->shouldReceive('hasQuote')->andReturnTrue();
        $this->checkoutSession->shouldReceive('getQuoteId')->andReturn($quoteId);

        $this->urlBuilder->shouldReceive('getUrl')->andReturn($redirectUrl);
        $this->urlBuilder->shouldReceive('getUrl')->andReturn($cancelUrl);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->build($buildSubject);
        $this->assertEquals($array, $result);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(CallbackUrlBuilder::class, [
            'urlBuilder' => $this->urlBuilder,
            'checkoutSession' => $this->checkoutSession,
        ]);
    }
}
