<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Request;

use Eway\IFrame\Gateway\Request\SecuredCardDataBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class SecuredCardDataBuilderTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
    }

    public function testBuild()
    {
        $payment = $this->getPaymentDataObjectInterfaceMock();
        $buildSubject = [
            'payment' => $payment,
        ];
        $securedCardData = '123';

        $array = [
            'SecuredCardData' => '123',
        ];

        $paymentModel = $this->getInfoInterfaceMock();
        $payment->shouldReceive('getPayment')->andReturn($paymentModel);
        $paymentModel->shouldReceive('getAdditionalInformation')->andReturn($securedCardData);
        $subject = $this->getSubjectUnderTest();
        $result = $subject->build($buildSubject);
        $this->assertEquals($array, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|PaymentDataObjectInterface
     */
    public function getPaymentDataObjectInterfaceMock()
    {
        return Mockery::mock(PaymentDataObjectInterface::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(SecuredCardDataBuilder::class);
    }
}
