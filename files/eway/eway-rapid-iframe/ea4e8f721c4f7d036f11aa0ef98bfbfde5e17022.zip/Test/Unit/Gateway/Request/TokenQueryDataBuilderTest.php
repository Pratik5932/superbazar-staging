<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Request;

use Eway\IFrame\Gateway\Request\TokenQueryDataBuilder;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Payment\Model\InfoInterface;
use Mockery;
use Mockery\LegacyMockInterface;
use Mockery\MockInterface;
use PHPUnit\Framework\TestCase;

class TokenQueryDataBuilderTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
    }

    public function testBuild()
    {
        $payment = $this->getPaymentDataObjectInterfaceMock();
        $buildSubject = [
            'payment' => $payment,
        ];
        $tokenCustomerId = '123';

        $array = [
            'TokenCustomerID' => $tokenCustomerId,
        ];

        $paymentModel = $this->getInfoInterfaceMock();
        $payment->shouldReceive('getPayment')->andReturn($paymentModel);
        $paymentModel->shouldReceive('getAdditionalInformation')->andReturn($tokenCustomerId);
        $paymentModel->shouldReceive('setAdditionalInformation')->andReturnSelf();
        $subject = $this->getSubjectUnderTest();
        $result = $subject->build($buildSubject);
        $this->assertEquals($array, $result);
    }

    /**
     * @return LegacyMockInterface|MockInterface|PaymentDataObjectInterface
     */
    public function getPaymentDataObjectInterfaceMock()
    {
        return Mockery::mock(PaymentDataObjectInterface::class);
    }

    /**
     * @return InfoInterface|LegacyMockInterface|MockInterface
     */
    public function getInfoInterfaceMock()
    {
        return Mockery::mock(InfoInterface::class);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(TokenQueryDataBuilder::class);
    }
}
