<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Validator;

use Eway\IFrame\Gateway\Validator\DirectResponseValidator;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use PHPUnit\Framework\TestCase;

class DirectResponseValidatorTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
    }

    public function testValidate()
    {
        $response = [
            'Customer' => [
                'CardDetails' => [],
            ],
        ];
        $amount = '1000';
        $validationSubjectArray = [
            'response' => $response,
            'amount' => $amount,
        ];

        $subject = $this->getSubjectUnderTest();
        $result = $subject->validate($validationSubjectArray);
        $this->assertNull($result);
    }

    public function testValidateCardDetails()
    {
        $response = [
            'Customer' => [
                'CardDetails' => [],
            ],
        ];
        $subject = $this->getSubjectUnderTestPartial();
        $result = $subject->validateCardDetails($response);
        $this->assertFalse($result);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(DirectResponseValidator::class);
    }

    /**
     * @return Mockery\Mock
     */
    public function getSubjectUnderTestPartial()
    {
        return Mockery::mock(DirectResponseValidator::class)->shouldAllowMockingProtectedMethods()->makePartial();
    }
}
