<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Validator;

use Eway\IFrame\Gateway\Validator\TransactionQueryResponseValidator;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Mockery;
use PHPUnit\Framework\TestCase;

class TransactionQueryResponseValidatorTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
    }

    public function testValidate()
    {
        $response = [
            'TotalAmount' => '10000',
        ];
        $amount = '1000';
        $validationSubjectArray = [
            'response' => $response,
            'amount' => $amount,
        ];

        $subject = $this->getSubjectUnderTest();
        $result = $subject->validate($validationSubjectArray);
        $this->assertNull($result);
    }

    public function testValidateTotalAmount()
    {
        $response = [
            'TotalAmount' => '10000',
        ];
        $amount = '1000';
        $subject = $this->getSubjectUnderTestPartial();
        $result = $subject->validateTotalAmount($response, $amount);
        $this->assertFalse($result);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(TransactionQueryResponseValidator::class);
    }

    /**
     * @return Mockery\Mock
     */
    public function getSubjectUnderTestPartial()
    {
        return Mockery::mock(TransactionQueryResponseValidator::class)
            ->shouldAllowMockingProtectedMethods()->makePartial();
    }
}
