<?php

declare(strict_types=1);

namespace Eway\IFrame\Test\Unit\Gateway\Validator;

use Eway\IFrame\Gateway\Validator\QueryAccessCodeResponseValidator;
use Magento\Framework\TestFramework\Unit\Helper\ObjectManager;
use Magento\Payment\Gateway\Helper\SubjectReader;
use PHPUnit\Framework\TestCase;

class QueryAccessCodeResponseValidatorTest extends TestCase
{
    /**
     * @var ObjectManager
     */
    protected $objectManager;

    protected function setUp()
    {
        parent::setUp();
        $this->objectManager = new ObjectManager($this);
    }

    public function validate(array $validationSubject)
    {
        $response = SubjectReader::readResponse($validationSubject);

        $errorMessages = [];
        $validationResult = $this->validateErrors($response)
            && $this->validateResponseCode($response)
            && $this->validateResponseMessage($response);

        if (!$validationResult) {
            $errorMessages = [__('Transaction has been declined, please, try again later.')];
        }

        return $this->createResult($validationResult, $errorMessages); /** @phpstan-ignore-line */
    }

    public function testValidate()
    {
        $response = [
            'TotalAmount' => '10000',
        ];
        $validationSubjectArray = [
            'response' => $response,
        ];

        $subject = $this->getSubjectUnderTest();
        $result = $subject->validate($validationSubjectArray);
        $this->assertNull($result);
    }

    /**
     * @return object
     */
    public function getSubjectUnderTest()
    {
        return $this->objectManager->getObject(QueryAccessCodeResponseValidator::class);
    }
}
