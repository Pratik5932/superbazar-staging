<?php

declare(strict_types=1);

namespace Eway\IFrame\Controller\Mycard;

use Eway\IFrame\Model\GetAccessCodeService;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\DataObject;

class GetAccessCode extends Action
{
    /**
     * @var GetAccessCodeService
     */
    protected $getAccessCodeService;

    /**
     * @var \Magento\Directory\Helper\Data
     */
    private $directoryHelper;

    public function __construct(
        Context $context,
        GetAccessCodeService $getAccessCodeService,
        \Magento\Directory\Helper\Data $directoryHelper
    ) {
        parent::__construct($context);
        $this->getAccessCodeService = $getAccessCodeService;
        $this->directoryHelper = $directoryHelper;
    }

    public function execute()
    {
        $request = $this->getRequest();

        $data = new DataObject($request->getParams());

        $countryId = $data->getData('country_id');
        $regionId = $data->getData('region_id');

        if ($countryId && $regionId && $this->directoryHelper->isRegionRequired($countryId)) {
            $regionData = $this->directoryHelper->getRegionData();
            $data->setData('region_code', $regionData[$countryId][$regionId]['code']);
        }

        return $this->getAccessCodeService->process($data);
    }
}
