<?php

declare(strict_types=1);

namespace Eway\IFrame\Controller\IFrame;

use Eway\IFrame\Model\GetAccessCodeTransactionService;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class GetAccessCode extends Action
{
    /** @var Session */
    protected $checkoutSession;

    /** @var GetAccessCodeTransactionService */
    protected $getAccessCodeTransactionService;

    public function __construct(
        Context $context,
        Session $checkoutSession,
        GetAccessCodeTransactionService $getAccessCodeTransactionService
    ) {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->getAccessCodeTransactionService = $getAccessCodeTransactionService;
    }

    public function execute()
    {
        $quote = $this->checkoutSession->getQuote();
        if (!$quote->getBillingAddress()->getEmail() && $this->getRequest()->getParam('GuestEmail')) {
            $quote->getBillingAddress()->setEmail($this->getRequest()->getParam('GuestEmail'));
        }

        return $this->getAccessCodeTransactionService->process($quote, $this->getRequest());
    }
}
