<?php

declare(strict_types=1);

namespace Eway\IFrame\Model\Ui;

use Eway\EwayRapid\Model\Config\Source\Mode;
use Eway\EwayRapid\Model\Config\Source\PaymentAction;
use Eway\EwayRapid\Model\Ui\ConfigProvider;
use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Command\CommandPool;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Model\CcGenericConfigProvider;

/**
 * @codeCoverageIgnore
 */
class Config implements \Eway\EwayRapid\Model\Ui\MethodSpecificConfigInterface
{
    const CONNECTION_TYPE = 'iframe';

    /** @var ConfigInterface */
    protected $config;

    /** @var UrlInterface */
    protected $urlBuilder;

    /** @var CommandPool */
    protected $commandPool;

    /**
     * @var CcGenericConfigProvider
     */
    protected $ccConfigProvider;

    /**
     * @var \Magento\Payment\Model\CcConfig
     */
    protected $ccConfig;

    /**
     * Config constructor.
     *
     * @param ConfigInterface                 $config
     * @param UrlInterface                    $urlBuilder
     * @param CommandPool                     $commandPool
     * @param CcGenericConfigProvider         $ccConfigProvider
     * @param \Magento\Payment\Model\CcConfig $ccConfig
     */
    public function __construct(
        ConfigInterface $config,
        UrlInterface $urlBuilder,
        CommandPool $commandPool,
        CcGenericConfigProvider $ccConfigProvider,
        \Magento\Payment\Model\CcConfig $ccConfig
    ) {
        $this->config = $config;
        $this->urlBuilder = $urlBuilder;
        $this->commandPool = $commandPool;
        $this->ccConfigProvider = $ccConfigProvider;
        $this->ccConfig = $ccConfig;
    }

    /**
     * @return string
     */
    public function getConnectionType()
    {
        return self::CONNECTION_TYPE;
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return 'IFrame';
    }

    /**
     * @return array
     */
    public function getMethodConfig()
    {
        return [
            'get_access_code_url' => $this->urlBuilder->getUrl('ewayrapid/iFrame/getAccessCode', ['_secure' => true]),
            'mycard_get_access_code_url' => $this->urlBuilder->getUrl(
                'ewayrapid/mycard/getAccessCode',
                ['_secure' => true]
            ),
            // In IFrame and Shared Page, create token only possible with capture
            'can_create_token' => $this->isAuthorizeCaptureAction(),
            // Use in case token is existed - Secure Fields
            'fieldStyles' => $this->config->getValue('field_styles'),
            'publicApiKey' => $this->getPublicApiKey(),
        ];
    }

    /**
     * @return string
     */
    protected function getPublicApiKey(): string
    {
        return Mode::SANDBOX == $this->config->getValue('mode') ?
            (string) $this->config->getValue('sandbox_public_api_key') :
            (string) $this->config->getValue('live_public_api_key');
    }

    /**
     * @param array  $config
     * @param string $field
     *
     * @return array
     */
    protected function getCcConfig(array $config, string $field): array
    {
        if ($config && isset($config['payment']['ccform'][$field][ConfigProvider::CODE])) {
            return $config['payment']['ccform'][$field][ConfigProvider::CODE];
        }

        return [];
    }

    /**
     * @return string
     */
    protected function getEncryptionKey(): string
    {
        return Mode::SANDBOX == $this->config->getValue('mode') ?
            (string) $this->config->getValue('sandbox_encryption_key') :
            (string) $this->config->getValue('live_encryption_key');
    }

    /**
     * @return bool
     */
    protected function isAuthorizeCaptureAction()
    {
        return PaymentAction::ACTION_AUTHORIZE_CAPTURE == $this->config->getValue('payment_action');
    }

    /**
     * @return string;
     */
    public function getMethodRendererPath()
    {
        return 'Eway_IFrame/js/view/payment/method-renderer/iframe';
    }

    /**
     * @return \Magento\Payment\Gateway\Command\CommandPool
     */
    public function getCommandPool()
    {
        return $this->commandPool;
    }

    /**
     * @return string
     */
    public function getMycardFormBlock()
    {
        return 'EwayRapidIFrameMycardForm';
    }
}
