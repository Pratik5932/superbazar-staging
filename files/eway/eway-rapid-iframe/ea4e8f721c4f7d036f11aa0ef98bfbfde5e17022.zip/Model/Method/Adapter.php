<?php

declare(strict_types=1);

namespace Eway\IFrame\Model\Method;

use Eway\EwayRapid\Model\Config;

class Adapter extends \Magento\Payment\Model\Method\Adapter
{
    /**
     * @param \Magento\Framework\DataObject $data
     *
     * @return $this|Adapter
     *
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function assignData(\Magento\Framework\DataObject $data)
    {
        parent::assignData($data);

        if (($addtionalData = $data->getData('additional_data')) && isset($addtionalData[Config::ACCESS_CODE])) {
            $this->getInfoInstance()->setAdditionalInformation(
                Config::ACCESS_CODE,
                $addtionalData[Config::ACCESS_CODE]
            );
        }
        $addtionalFields = [
            Config::TOKEN_ACTION, Config::TOKEN_ID,
            Config::CARD_NUMBER, Config::CARD_CVN, Config::CARD_NAME,
            Config::CARD_EXPIRY_MONTH, Config::CARD_EXPIRY_YEAR, Config::SECURED_CARD_DATA,
        ];

        foreach ($addtionalFields as $field) {
            if (isset($addtionalData[$field])) {
                $this->getInfoInstance()->setAdditionalInformation($field, $addtionalData[$field]);
            }
        }

        return $this;
    }
}
