<?php

declare(strict_types=1);

namespace Eway\IFrame\Gateway\Validator;

use Eway\EwayRapid\Gateway\Validator\AbstractResponseValidator;
use Eway\EwayRapid\Model\Config;
use Magento\Payment\Gateway\Helper\SubjectReader;

class DirectResponseValidator extends AbstractResponseValidator
{
    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function validate(array $validationSubject)
    {
        $response = SubjectReader::readResponse($validationSubject);
        $amount = (float) SubjectReader::readAmount($validationSubject);

        $errorMessages = [];
        $validationResult = $this->validateErrors($response)
            && $this->validateTotalAmount($response, $amount)
            && $this->validateTransactionType($response)
            && $this->validateTransactionStatus($response)
            && $this->validateTransactionId($response)
            && $this->validateResponseMessage($response)
            && $this->validateAuthorisationCode($response)
            && $this->validateCardDetails($response);

        if (!$validationResult) {
            $errorMessages = [__('Transaction has been declined, please, try again later.')];
        }

        return $this->createResult($validationResult, $errorMessages); /** @phpstan-ignore-line */
    }

    /**
     * @param array $response
     *
     * @return bool
     */
    protected function validateCardDetails(array $response)
    {
        return !empty($response[Config::CUSTOMER][Config::CARD_DETAILS]);
    }
}
