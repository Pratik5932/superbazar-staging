<?php

declare(strict_types=1);

namespace Eway\IFrame\Gateway\Request;

use Eway\EwayRapid\Model\Config;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Request\BuilderInterface;

class SecuredCardDataBuilder implements BuilderInterface
{
    /**
     * @param array $buildSubject
     *
     * @return array
     */
    public function build(array $buildSubject): array
    {
        $payment = SubjectReader::readPayment($buildSubject);

        $paymentModel = $payment->getPayment();

        return [Config::SECURED_CARD_DATA => $paymentModel->getAdditionalInformation(Config::SECURED_CARD_DATA)];
    }
}
