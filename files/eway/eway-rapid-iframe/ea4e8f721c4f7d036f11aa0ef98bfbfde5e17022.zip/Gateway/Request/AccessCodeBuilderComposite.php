<?php

declare(strict_types=1);

namespace Eway\IFrame\Gateway\Request;

use Magento\Framework\ObjectManager\TMapFactory;
use Magento\Payment\Gateway\ConfigInterface;

class AccessCodeBuilderComposite extends \Eway\EwayRapid\Gateway\Request\BuilderComposite
{
    /**
     * AccessCodeBuilderComposite constructor.
     *
     * @param TMapFactory     $tmapFactory
     * @param ConfigInterface $config
     * @param string          $method
     * @param array           $builders
     * @codeCoverageIgnore
     */
    public function __construct(
        TMapFactory $tmapFactory,
        ConfigInterface $config,
        string $method = '',
        array $builders = []
    ) {
        if ('' == $method) {
            $connectionType = $config->getValue('connection_type');
            switch ($connectionType) {
                case 'iframe':
                case 'sharedpage':
                    $method = \Eway\Rapid\Enum\ApiMethod::RESPONSIVE_SHARED;
                    break;
                case 'transparent':
                    $method = \Eway\Rapid\Enum\ApiMethod::TRANSPARENT_REDIRECT;
                    break;
            }
        }

        parent::__construct($tmapFactory, $method, $builders);
    }
}
