define(
    [
        'jquery',
        'Eway_EwayRapid/js/view/payment/method-renderer/common',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Magento_Checkout/js/action/set-payment-information',
        'Eway_DirectConnection/js/model/credit-card-validation/validator'
    ],
    function ($, Component, quote, additionalValidators, setPaymentInformationAction) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Eway_IFrame/payment/ewayrapid-iframe'
            },

            sharedPaymentUrl: '',
            accessCode: '',
            shouldPlaceOrder: false,
            showFullCard: false,
            validFields: {'cvn': false},
            publicApiKeyError: false,


            loadScript: function () {
                var self = this;
                var state = this.scriptLoaded;
                $('body').trigger('processStart');
                require(['ewayecrypt'], function () {
                    state(true);
                    eCrypt.init();
                });
                require(['ewayrapid'], function () {
                    state(true);
                    self.setupSecureFields();
                    $('body').trigger('processStop');
                });
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'showFullCard',
                    ]);
                return this;
            },

            onTokenSelect: function (token) {
                this._super(token);
                this.showFullCard(!!token);
                if (this.publicApiKeyError) {
                    this.validate();
                }
            },

            validate: function (field) {
                if (field == undefined) {
                    var result = true;
                    for (field in this.validFields) {
                        result = this.validate(field) && result;
                    }
                    return result;
                } else {
                    if (!this.showFullCard() && field != 'cvn') {
                        // Do not validate other fields except cvn in case using token payment
                        return true;
                    }

                    if (!this.showFullCard() && field == 'cvn' && !this.getTokenId()) {
                        // Do not validate cvn in case using new token payment
                        return true;
                    }

                    if (this.isEditing() && field == 'card') {
                        // Do not validate card number when update token
                        return true;
                    }

                    if (!this.validFields[field]) {
                        if (this.publicApiKeyError) {
                            $('#eway-secure-field-' + field + '-error').html('Invalid Public API Key');
                        }
                        $('#eway-secure-field-' + field + '-error').show();
                        return false;
                    } else {
                        $('#eway-secure-field-' + field + '-error').hide();
                        return true;
                    }
                }
            },

            canCreateToken: function () {
                return this.getMethodConfigData('can_create_token');
            },

            getTokenId: function () {
                return this.selectedToken() ? this.selectedToken().token_id : '';
            },

            getAccessCode: function () {
                var self = this;
                var url = this.getMethodConfigData('get_access_code_url');
                var data = {};
                if (quote.guestEmail) {
                    data['GuestEmail'] = quote.guestEmail;
                }
                if (this.isTokenEnabled()) {
                    if (this.saveCard() && this.canCreateToken()) {
                        data['TokenAction'] = 'new';
                    }
                }
                return $.ajax(url, {method: "POST", data: data})
                    .done(function (data) {
                        self.sharedPaymentUrl = data['shared_payment_url'];
                        self.accessCode = data['access_code'];
                    }).fail(function (jqXHR) {
                        var data = jqXHR.responseJSON;
                        alert(data['error'] ? data['error'] : 'Unknown error happened');
                        $('body').trigger('processStop');
                        self.isPlaceOrderActionAllowed(true);
                        self.shouldPlaceOrder = false;
                    });
            },

            iframeResultCallback: function (result, transactionID, errors) {
                if (result == "Complete") {
                    this.shouldPlaceOrder = true;
                    this.isPlaceOrderActionAllowed(true);
                    this.placeOrder();
                } else {
                    if (result == "Error") {
                        alert("There was a problem completing the payment: " + errors);
                    }
                    $('body').trigger('processStop');
                    this.isPlaceOrderActionAllowed(true);
                    this.shouldPlaceOrder = false;
                }
            },

            setupSecureFields: function () {
                var publicApiKey = this.getMethodConfigData('publicApiKey');
                var fieldStyles = this.getMethodConfigData('fieldStyles');

                var fields = {
                    cvnFieldConfig : {
                        publicApiKey: publicApiKey,
                        fieldDivId: "eway-secure-field-cvn",
                        fieldType: "cvn",
                        styles: fieldStyles
                    }
                };
                var callBack = this.secureFieldCallback.bind(this);
                for (var field in fields) {
                    $('#' + fields[field].fieldDivId).empty();
                    eWAY.setupSecureField(fields[field], callBack);
                }
            },

            secureFieldCallback: function (event) {
                var field = event.targetField;
                if (!event.fieldValid || !event.valueIsValid) {
                    this.validFields[field] = false;
                    if (event.errors == 'V6143') {
                        this.publicApiKeyError = true;
                    }
                } else {
                    this.validFields[field] = true;
                    // set the hidden Secure Field Code field
                    $('#secured_card_data').val(event.secureFieldCode);
                }
                this.validate(field);
            },

            getPlaceOrderDeferredObject: function () {
                var self = this;
                return this._super().fail(function () {
                    if (self.getTokenId()) {
                        self.validFields = {'name': false, 'card': false, 'expiry': false, 'cvn': false};
                        self.setupSecureFields();
                    }
                    $('body').trigger('processStop');
                    self.shouldPlaceOrder = false;
                    self.isPlaceOrderActionAllowed(true);
                });
            },

            getAdditionalData: function () {
                if (this.getTokenId()) {
                    return {
                        'SecuredCardData': $('#secured_card_data').val()
                    };
                }
                return {
                    'AccessCode': this.accessCode
                };
            },

            placeOrder: function () {
                var self = this;
                if (this.shouldPlaceOrder) {
                    this._super();
                } else {
                    if (this.validate() && additionalValidators.validate()) {
                        if (!this.getTokenId()) {
                            $('body').trigger('processStart');
                            this.isPlaceOrderActionAllowed(false);
                            $.when(
                                setPaymentInformationAction(
                                    this.messageContainer,
                                    {
                                        method: this.getCode()
                                    }
                                )
                            )
                                .then(self.getAccessCode.bind(self))
                                .done(function () {
                                    var eWAYConfig = {
                                        sharedPaymentUrl: self.sharedPaymentUrl
                                    };
                                    eCrypt.showModalPayment(eWAYConfig, self.iframeResultCallback.bind(self));
                                })
                                .fail(function () {
                                    $('body').trigger('processStop');
                                    self.isPlaceOrderActionAllowed(true);
                                    self.shouldPlaceOrder = false;
                                })
                        } else {
                            this._super();
                        }
                    }
                }
            }
        });
    }
);
