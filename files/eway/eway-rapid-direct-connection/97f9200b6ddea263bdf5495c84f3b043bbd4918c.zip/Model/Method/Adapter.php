<?php

declare(strict_types=1);

namespace Eway\DirectConnection\Model\Method;

use Eway\EwayRapid\Model\Config;
use Eway\EwayRapid\Model\Config\Source\Mode;
use Magento\Framework\Event\ManagerInterface;
use Magento\Payment\Gateway\Command\CommandManagerInterface;
use Magento\Payment\Gateway\Command\CommandPoolInterface;
use Magento\Payment\Gateway\Config\ValueHandlerPoolInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectFactory;
use Magento\Payment\Gateway\Validator\ValidatorPoolInterface;
use Magento\Quote\Api\Data\CartInterface;

class Adapter extends \Magento\Payment\Model\Method\Adapter
{
    /**
     * @var \Magento\Payment\Gateway\ConfigInterface
     */
    protected $config;

    /**
     * Adapter constructor.
     *
     * @param ManagerInterface                         $eventManager
     * @param ValueHandlerPoolInterface                $valueHandlerPool
     * @param PaymentDataObjectFactory                 $paymentDataObjectFactory
     * @param string                                   $code
     * @param string                                   $formBlockType
     * @param string                                   $infoBlockType
     * @param \Magento\Payment\Gateway\ConfigInterface $config
     * @param null|CommandPoolInterface                $commandPool
     * @param null|ValidatorPoolInterface              $validatorPool
     * @param null|CommandManagerInterface             $commandExecutor
     */
    public function __construct(
        ManagerInterface $eventManager,
        ValueHandlerPoolInterface $valueHandlerPool,
        PaymentDataObjectFactory $paymentDataObjectFactory,
        string $code,
        string $formBlockType,
        string $infoBlockType,
        \Magento\Payment\Gateway\ConfigInterface $config,
        CommandPoolInterface $commandPool = null,
        ValidatorPoolInterface $validatorPool = null,
        CommandManagerInterface $commandExecutor = null
    ) {
        parent::__construct(
            $eventManager,
            $valueHandlerPool,
            $paymentDataObjectFactory,
            $code,
            $formBlockType,
            $infoBlockType,
            $commandPool,
            $validatorPool,
            $commandExecutor
        );
        $this->config = $config;
    }

    public function assignData(\Magento\Framework\DataObject $data)
    {
        parent::assignData($data);

        $addtionalFields = [
            Config::TOKEN_ACTION, Config::TOKEN_ID,
            Config::CARD_NUMBER, Config::CARD_CVN, Config::CARD_NAME,
            Config::CARD_EXPIRY_MONTH, Config::CARD_EXPIRY_YEAR, Config::SECURED_CARD_DATA,
        ];
        $addtionalData = $data->getData('additional_data');

        foreach ($addtionalFields as $field) {
            if (isset($addtionalData[$field])) {
                $this->getInfoInstance()->setAdditionalInformation($field, $addtionalData[$field]);
            }
        }

        return $this;
    }

    public function isAvailable(CartInterface $quote = null)
    {
        $storeId = $quote ? $quote->getStoreId() : null;
        $result = Mode::SANDBOX == $this->config->getValue('mode', $storeId) ?
            !empty($this->config->getValue('sandbox_encryption_key', $storeId)) :
            !empty($this->config->getValue('live_encryption_key', $storeId));

        return $result && parent::isAvailable($quote);
    }
}
