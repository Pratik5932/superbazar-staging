<?php

declare(strict_types=1);

namespace Eway\DirectConnection\Model\Ui;

use Eway\EwayRapid\Model\Config\Source\Mode;
use Eway\EwayRapid\Model\Ui\ConfigProvider;
use Magento\Payment\Gateway\Command\CommandPool;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Payment\Model\CcGenericConfigProvider;

class Config implements \Eway\EwayRapid\Model\Ui\MethodSpecificConfigInterface
{
    const CONNECTION_TYPE = 'direct';

    /**
     * @var ConfigInterface
     */
    protected $config;

    /**
     * @var CommandPool
     */
    protected $commandPool;

    /**
     * @var CcGenericConfigProvider
     */
    protected $ccConfigProvider;

    /**
     * @var \Magento\Payment\Model\CcConfig
     */
    protected $ccConfig;

    public function __construct(
        ConfigInterface $config,
        CommandPool $commandPool,
        CcGenericConfigProvider $ccConfigProvider,
        \Magento\Payment\Model\CcConfig $ccConfig
    ) {
        $this->config = $config;
        $this->commandPool = $commandPool;
        $this->ccConfigProvider = $ccConfigProvider;
        $this->ccConfig = $ccConfig;
    }

    /**
     * @return string
     */
    public function getConnectionType()
    {
        return self::CONNECTION_TYPE;
    }

    /**
     * @return string
     */
    public function getLabel()
    {
        return 'Direct Connection';
    }

    /**
     * @return array
     */
    public function getMethodConfig()
    {
        $config = $this->ccConfigProvider->getConfig();
        $visaCheckoutApiKey = $this->config->getValue('visa_checkout_apikey');

        return [
            'encryptionKey' => $this->getEncryptionKey(),
            'availableTypes' => $this->getCcConfig($config, 'availableTypes'),
            'months' => $this->getCcConfig($config, 'months'),
            'years' => $this->getCcConfig($config, 'years'),
            'enable_visa_checkout' => $this->config->getValue('enable_visa_checkout') && !empty($visaCheckoutApiKey),
            'visa_image_url' => $this->ccConfig->getViewFileUrl('Eway_TransparentRedirect::images/visa_checkout.png'),
            'visa_sdk_url' => \Eway\EwayRapid\Model\Config::getVisaCheckoutSdkUrl(
                (string) $this->config->getValue('mode')
            ),
            'visa_checkout_apikey' => $visaCheckoutApiKey,
        ];
    }

    /**
     * @param array  $config
     * @param string $field
     *
     * @return array
     */
    protected function getCcConfig(array $config, string $field): array
    {
        if ($config && isset($config['payment']['ccform'][$field][ConfigProvider::CODE])) {
            return $config['payment']['ccform'][$field][ConfigProvider::CODE];
        }

        return [];
    }

    /**
     * @return string
     */
    protected function getEncryptionKey(): string
    {
        return Mode::SANDBOX == $this->config->getValue('mode') ?
            (string) $this->config->getValue('sandbox_encryption_key') :
            (string) $this->config->getValue('live_encryption_key');
    }

    /**
     * @return string;
     */
    public function getMethodRendererPath()
    {
        return 'Eway_DirectConnection/js/view/payment/method-renderer/direct';
    }

    /**
     * @return \Magento\Payment\Gateway\Command\CommandPool
     */
    public function getCommandPool()
    {
        return $this->commandPool;
    }

    /**
     * @return string
     */
    public function getMycardFormBlock()
    {
        return 'EwayRapidDirectMycardForm';
    }
}
