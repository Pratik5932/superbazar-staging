<?php

declare(strict_types=1);

namespace JMS\Serializer\Exception;

class UninitializedPropertyException extends RuntimeException implements Exception
{
}
