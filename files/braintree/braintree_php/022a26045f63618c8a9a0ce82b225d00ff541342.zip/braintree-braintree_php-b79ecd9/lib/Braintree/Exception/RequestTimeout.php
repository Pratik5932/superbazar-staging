<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when a client request timeout occurs.
 */
class RequestTimeout extends Exception
{
}
