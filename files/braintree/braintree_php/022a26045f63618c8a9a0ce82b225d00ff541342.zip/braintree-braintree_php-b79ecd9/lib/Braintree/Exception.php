<?php

namespace Braintree;

/**
 * super class for all Braintree exceptions
 */
class Exception extends \Exception
{
}
