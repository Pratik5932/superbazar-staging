2.0.10
=============
* Added support of Magento 2.3.x to composer
