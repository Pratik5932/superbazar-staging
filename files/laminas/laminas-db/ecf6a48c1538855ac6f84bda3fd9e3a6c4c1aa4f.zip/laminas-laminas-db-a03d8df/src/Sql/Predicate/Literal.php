<?php

namespace Laminas\Db\Sql\Predicate;

use Laminas\Db\Sql\Literal as BaseLiteral;

class Literal extends BaseLiteral implements PredicateInterface
{
}
