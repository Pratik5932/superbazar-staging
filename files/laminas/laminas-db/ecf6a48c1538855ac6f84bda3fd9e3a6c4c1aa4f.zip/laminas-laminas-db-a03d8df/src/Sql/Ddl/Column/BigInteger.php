<?php

namespace Laminas\Db\Sql\Ddl\Column;

class BigInteger extends Integer
{
    /** @var string */
    protected $type = 'BIGINT';
}
