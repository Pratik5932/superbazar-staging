<?php

namespace Laminas\Db\Adapter\Exception;

class InvalidQueryException extends UnexpectedValueException implements ExceptionInterface
{
}
