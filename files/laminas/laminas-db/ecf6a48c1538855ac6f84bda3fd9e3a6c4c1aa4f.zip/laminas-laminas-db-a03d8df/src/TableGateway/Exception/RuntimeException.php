<?php

namespace Laminas\Db\TableGateway\Exception;

use Laminas\Db\Exception;

class RuntimeException extends Exception\InvalidArgumentException implements ExceptionInterface
{
}
