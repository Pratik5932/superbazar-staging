<?php

namespace Laminas\Db\Adapter\Exception;

use Laminas\Db\Exception;

class RuntimeException extends Exception\RuntimeException implements ExceptionInterface
{
}
