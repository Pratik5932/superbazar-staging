<?php

namespace Laminas\Db\Sql\Exception;

use Laminas\Db\Exception;

class RuntimeException extends Exception\RuntimeException implements ExceptionInterface
{
}
