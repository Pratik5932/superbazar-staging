<?php

namespace Laminas\Db\Sql\Predicate;

use Laminas\Db\Sql\ExpressionInterface;

interface PredicateInterface extends ExpressionInterface
{
}
