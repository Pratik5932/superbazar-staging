<?php

namespace Laminas\Db\Sql;

class Where extends Predicate\Predicate
{
}
