<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Timestamp extends AbstractTimestampColumn
{
    /** @var string */
    protected $type = 'TIMESTAMP';
}
