<?php

namespace Laminas\Db\Sql\Ddl\Index;

use Laminas\Db\Sql\Ddl\Constraint\AbstractConstraint;

abstract class AbstractIndex extends AbstractConstraint
{
}
