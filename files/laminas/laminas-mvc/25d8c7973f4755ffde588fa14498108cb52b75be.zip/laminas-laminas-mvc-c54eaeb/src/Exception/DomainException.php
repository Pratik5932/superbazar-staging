<?php

namespace Laminas\Mvc\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
