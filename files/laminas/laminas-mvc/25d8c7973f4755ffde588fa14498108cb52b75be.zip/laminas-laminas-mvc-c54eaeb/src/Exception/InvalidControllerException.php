<?php

namespace Laminas\Mvc\Exception;

use Exception;

class InvalidControllerException extends Exception implements ExceptionInterface
{
}
