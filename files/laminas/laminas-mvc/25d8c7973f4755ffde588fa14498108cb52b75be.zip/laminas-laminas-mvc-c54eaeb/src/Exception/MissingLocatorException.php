<?php

namespace Laminas\Mvc\Exception;

class MissingLocatorException extends RuntimeException
{
}
