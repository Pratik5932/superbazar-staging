<?php

namespace Laminas\Soap\Exception;

/**
 * Common Exception interface
 */
interface ExceptionInterface
{
}
