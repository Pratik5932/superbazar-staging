<?php

namespace Laminas\I18n\Exception;

use DomainException;

class ExtensionNotLoadedException extends DomainException implements ExceptionInterface
{
}
