<?php

declare(strict_types=1);

namespace Laminas\View\Helper\Placeholder;

/**
 * Container for placeholder values
 */
class Container extends Container\AbstractContainer
{
}
