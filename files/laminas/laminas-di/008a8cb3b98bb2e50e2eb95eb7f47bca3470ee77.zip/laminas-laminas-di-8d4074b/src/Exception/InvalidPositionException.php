<?php

declare(strict_types=1);

namespace Laminas\Di\Exception;

class InvalidPositionException extends InvalidArgumentException
{
}
