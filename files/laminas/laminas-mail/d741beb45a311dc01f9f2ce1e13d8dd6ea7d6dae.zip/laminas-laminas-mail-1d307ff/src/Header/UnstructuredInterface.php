<?php

namespace Laminas\Mail\Header;

/**
 * Marker interface for unstructured headers.
 */
interface UnstructuredInterface extends HeaderInterface
{
}
