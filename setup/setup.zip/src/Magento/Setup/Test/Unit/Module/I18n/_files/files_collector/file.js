/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

(function() {
    $.mage.__('Phrase 1');
    $.mage.__('Phrase 1');
    $.mage.__('Phrase 2 %1');
});
