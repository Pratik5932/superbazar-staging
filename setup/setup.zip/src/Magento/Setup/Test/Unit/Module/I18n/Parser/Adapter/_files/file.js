/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

(function() {
    $.mage.__('Phrase 1');
    $.mage.__('Phrase 1');
    $.mage.__("Phrase 2 %1");
    let message = $t('Field ') + field + $t(' is required.');
    let html = $t('Welcome, %1!').replace('%1', 'John Doe');
});
